package wizard_management;

public class Dragon extends MythicalBeast {

  public Dragon(String name){
    super(name);
  }

  public String fly(){
    return "Standing up tall, beating wings, lift off!";
  }

}