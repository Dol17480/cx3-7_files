public class Salmon implements Edible{
  
}