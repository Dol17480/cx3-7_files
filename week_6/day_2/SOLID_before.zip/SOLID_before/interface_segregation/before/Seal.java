public class Seal implements Edible{
  
}