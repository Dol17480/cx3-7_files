public class Human implements Edible{
  
}