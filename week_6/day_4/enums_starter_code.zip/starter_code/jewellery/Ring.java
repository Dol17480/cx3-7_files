package jewellery;

public class Ring {

  private String metal;

  public Ring(String metal) {
    this.metal = metal;
  }

  public String getMetal(){
    return this.metal;
  }

}