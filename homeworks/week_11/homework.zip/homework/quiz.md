# Quiz

1. What does DOM stand for?

2. What is the name of the object we can use to get information about the browser enviroment?

3. What is the name of the object that we can use to get access to the DOM representation of the page?

4. What type of files might we see in the Network tab for in Chrome devTools?

5. What version of HTML is document.querySelector from?

6. Which event do we hook into when we want to know the DOM has loaded, window.onload or document.onload?

7. We use window.createElement to make new DOM elements, true or false?

8. List two ways to get all the elements by class 'cat'

9. List two ways to retrieve the element with id "goat"

10. List two ways to get all the li elements

11. List two ways to get the first li element

12. How can we set the a given element to be hidden?

